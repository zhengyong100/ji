<table align="center" width="100%" height="20" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#B3B3B3" class='table table-striped table-bordered'>
  <tr>
    <td align="center" bgcolor="#EBEBEB">Copyright &copy; 2018 <a href="http://xptt.com/">Xptt</a>. 记账多用户版</td>
  </tr>
</table>
</div>
</div>
    <!-- JavaScript 放置在文档最后面可以使页面加载速度更快 -->
    <!-- 可选: 包含 jQuery 库 -->
    <script src="js/jquery.min.js"></script>
    <!-- 可选: 合并了 Bootstrap JavaScript 插件 -->
    <script src="js/bootstrap.min.js"></script>
	<!-- 时间日期 插件 -->
	<script type="text/javascript" src="js/datetime.js"></script>
</body>
</html>